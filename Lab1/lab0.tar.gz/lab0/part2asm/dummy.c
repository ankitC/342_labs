


void strTable(char *s, char *d, int sl, int dl){

int i;
int t1;//t2;
//char c1,c2;

	for(i = 0; i < dl ; i += 1){

		t1 = d[i] - 23;
	
		while(t1 > 22)
			t1 = t1 - 23;

//		t2 = d[i+1] - 23;

//		while(t2 > 22)
//			t2 = t2 - 23;

		if(t1 <= sl){
			
				s[t1] = d[t1];
		}
		
//		if(t2 <= sl){
//
//		s[t2] = d[t2];		

//		}


	}


}
