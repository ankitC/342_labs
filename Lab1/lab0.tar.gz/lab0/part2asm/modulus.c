
int modulus(int a, int b){

	int c = a % b;

	return c;


}
