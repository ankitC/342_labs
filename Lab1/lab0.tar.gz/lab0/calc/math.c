#include<stdio.h>
#include"math.h"

int add(int val1,int val2){

	return (val1 + val2);

}

int sub(int val1,int val2){

	return (val1 - val2);

}

int mul(int val1,int val2){

	return (val1 * val2);

}

int cdiv(int val1,int val2){

	if(val2 == 0){
		printf("Error : Division by zero : ");
		return -1;
	}

	return (val1 / val2);

}

int mod(int val1,int val2){
	
	if(val2 == 0){
		printf("Error : Division by zero : ");
		return -1;
	}

	return (val1 % val2);
}
