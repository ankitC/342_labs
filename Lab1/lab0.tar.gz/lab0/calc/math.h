int add(int val1,int val2);
int sub(int val1,int val2);
int mul(int val1,int val2);
int cdiv(int val1,int val2);
int mod(int val1,int val2);
