#include<stdio.h>
#include<stdlib.h>
#include"math.h"

int main(int argc,char **argv){

	char buffer[25],str1[10],str2[10];
	char *error;
	int val1,val2;
	char op;
	int d;

	while(1){	

		if(fgets(buffer,25,stdin) == NULL){
			printf("Error reading command\n");
			exit(0);
		}
		
		if((d = sscanf(buffer,"%s %c %s",str1,&op,str2)) != 3){

//			printf("You entered %s %c %s with return of %d\n",str1,op,str2,d);
			printf("Format Error, Usage :\n[operand 1] [operation] [operand 2]\n");
			printf("operation : + - / %%\n"); 
			exit(0);
		}
		
		val1 = strtol(str1,&error,10);

		if(*error){
			printf("Invalid Argument!\n");
			exit(0);	
		}		

		val2 = strtol(str2,&error,10);

		if(*error){
			printf("Invalid Argument!\n");
			exit(0);	
		}		

		switch(op){

			case '+': printf("%d\n",add(val1,val2));
				  break;	

			case '-': printf("%d\n",sub(val1,val2));
				  break;	

			case '*': printf("%d\n",mul(val1,val2));
				  break;	

			case '/': printf("%d\n",cdiv(val1,val2));
				  break;	

			case '%': printf("%d\n",mod(val1,val2));
				  break;	
			
			default :
				  printf("Invalid Operation '%c'\n",op);
				  exit(0);
		}

	}

}
