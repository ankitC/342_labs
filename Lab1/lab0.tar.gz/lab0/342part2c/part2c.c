#include <stdlib.h>
#include <stdio.h>

/**
 * Function: oddball
 * Description: Baseline implementation for finding the number that
 *   occurs only once in the array.
 * Arguments:
 *   arr - pointer to start of integer array
 *   len - number of elements in array
 * Return:
 *   The number that occurs only once
 */
#ifdef DEFAULT
int oddball(int *arr, int len) {
	int i, j;
	int foundInner;
	int result = 0;

	for (i = 0; i < len; i++) {
		foundInner = 0;
		for (j = 0; j < len; j++) {
			if (i == j) {
				continue;
			}
			if (arr[i] == arr[j]) {
				foundInner = 1;
			}
		}
		if (foundInner != 1) {
			result = arr[i];
		}
	}

	return result;
}
#endif

#ifdef OPTIMIZE1
int oddball(int *arr, int len) {
	/* Put your code here */
	int i;
	int result;
	result=arr[0];
 	for(i=len-1;i>0;i--)
	{
		result=result^arr[i];
	}
	return result;
}
#endif

#ifdef OPTIMIZE3
int oddball(int *arr, int len) {
	/* Put your code here */
	int i,j;
	int foundInner=0;
	int result=0;
	for(i=len-1;i>=0;i--)
	{	
		if(arr[i]==0)
		{	
			continue;
		}
		foundInner=0;

		for(j=i-1;j>=0;j--)
		{
			if(arr[i]==arr[j])
			{
				foundInner=1;
				arr[i]=arr[j]=0;
				break;
			}
		}
		if(foundInner==0)
		{
			result=arr[i];
		}
	}
	return result;
}
#endif

#ifdef OPTIMIZE2

void merge(int a[], int low, int mid, int high)
{
    int b[100];
    int i = low, j = mid + 1, k = 0;
  
    while (i <= mid && j <= high) {
        if (a[i] <= a[j])
            b[k++] = a[i++];
        else
            b[k++] = a[j++];
    }
    while (i <= mid)
        b[k++] = a[i++];
  
    while (j <= high)
        b[k++] = a[j++];
  
    k--;
    while (k >= 0) {
        a[low + k] = b[k];
        k--;
    }
}
  
void mergesort(int a[], int low, int high)
{
    if (low < high) {
        int m = (high + low)/2;
        mergesort(a, low, m);
        mergesort(a, m + 1, high);
        merge(a, low, m, high);
    }
}

int oddball(int *arr, int len) {

	int i;

	mergesort(arr,0,(len - 1));
	
	for(i = 0; i < len;){

		if(i == (len - 1))
			return arr[i];

		if(arr[i] == arr[i+1]){
			i += 2;
		}
		else
			return arr[i];
	}

	return -1;
}
#endif

/**
 * Function: randGenerator
 * Description: Generate a random array that is in compliance with
 *   lab specification
 * Arguments:
 *   arr - pointer to start of integer array
 *   len - number of elements in array
 * Return:
 *   Unused, but feel free to utilize it.
 */

int randGenerator(int *arr, int len) {
	int i, j, r, rcount;
	for (i = 0; i < len; i++) {
		do {
			rcount = 0;
			r = rand()%(len/2 + 1) + 1;
			for (j = 0; j < i && rcount < 2; j++) {
				if (arr[j] == r) {
					rcount++;
				}
			}
		} while(rcount >= 2);
		arr[i] = r;
		printf("%d ", r);
	}
	printf("\nDone generating\n");
	return 0;
}




