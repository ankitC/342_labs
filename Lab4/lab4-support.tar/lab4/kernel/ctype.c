/** @file ctype.c
 *
 * @brief Implementation of inline ctype.h functions.
 *
 * @author Kartik Subramanian <ksubrama@andrew.cmu.edu>
 * @date 2008-10-30
 */

#define IMPLEMENTATION
#include <ctype.h>
